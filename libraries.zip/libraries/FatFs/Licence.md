
See [license page](http://elm-chan.org/fsw/ff/doc/appnote.html#license)

> /*----------------------------------------------------------------------------/<br>
> /  FatFs - Generic FAT Filesystem Module  Rx.xx                              /<br>
> /-----------------------------------------------------------------------------/<br>
> /<br>
> / Copyright (C) 20xx, ChaN, all right reserved.<br>
> /<br>
> / FatFs module is an open source software. Redistribution and use of FatFs in<br>
> / source and binary forms, with or without modification, are permitted provided<br>
> / that the following condition is met:<br>
> /<br>
> / 1. Redistributions of source code must retain the above copyright notice,<br>
> /    this condition and the following disclaimer.<br>
> /<br>
> / This software is provided by the copyright holder and contributors "AS IS"<br>
> / and any warranties related to this software are DISCLAIMED.<br>
> / The copyright owner or contributors be NOT LIABLE for any damages caused<br>
> / by use of this software.<br>
> /----------------------------------------------------------------------------*/<br>
